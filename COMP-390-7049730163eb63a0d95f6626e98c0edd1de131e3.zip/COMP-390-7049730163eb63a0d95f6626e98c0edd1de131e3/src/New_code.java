import java.util.Scanner;

public class New_code {
    public static void main(String[] args) {
    Scanner input = new Scanner(System.in);

    int student_num = input.nextInt();
    }
}
